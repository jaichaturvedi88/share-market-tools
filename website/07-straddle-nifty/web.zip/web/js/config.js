export const FIXED_COUNT = 5;
export const STEP_STRIKE = 50;
