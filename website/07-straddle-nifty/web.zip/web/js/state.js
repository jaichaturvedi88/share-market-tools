export function createState() {
  return {
    header: [],
    dataRows: [],
    dateCols: [],
    loadedFileName: "",
    searchQuery: "",
  };
}
